% Screen clear and variable clear
clc;clear;
% Load data
filename1 = 'MODSred_';
filename2 = '1026W';
filename3 = '_ARP';
filename4 = '.\removal\61026_'; % for removal
filename = [filename1 filename2 filename3];
fileext = '.txt';
[F1x, F1y] = textread([filename fileext],'%f %f','delimiter',' ');
%F1x = F1x*1000;
%F1y = F1y*1000000;
YY = interp1(F1x,F1y,(0:2:414)');
F1x = (0:2:414)';
F1y = YY;
1
totalsize = size(F1x,1);
% Make a changable version and an original version  F1y2 is original
% version
F1y2 = F1y;
% Stroke Parameters
preston_constant = 1800;
% % 4 in tool
% lapsize = 100; % mm
% spacing = .024; % in percent
% strokesize = .07; % in percent
% 5 in tool
lapsize = 5*25.4; % mm
spacing = 3.25*25.4/415; % in percent
strokesize = 2*25.4/415; % in percent
% Prep vectors and first guess at duration.
hi = .3 % high percent of removal
lo = .2 % low percent of removal
k = 1; % beginning bin
l = 4; % ending bin
stroke_center = zeros(l,1);
duration = zeros(l,2);
for i = 1:l
	duration(i,1) = i;
	duration(i,2) = 0;
end
2
bins = zeros(size(duration,1),5);
avediff_pre = zeros(size(duration,1),1);
for p = 1:size(duration,1)
	bins(p,1) = p;
	bins(p,3) = strokesize/2*415 + spacing*415*(p-1);
	bins(p,4) = strokesize/2*415 + spacing*415*(p-1) - lapsize/2 - strokesize/2*415;
	bins(p,5) = strokesize/2*415 + spacing*415*(p-1) + lapsize/2 + strokesize/2*415;
	end
for p = 1:size(duration,1)
	if mod(round(strokesize/2*415 + spacing*415*(p-1)),2) == 1
		bincenter(p,1) = round(strokesize/2*415 + spacing*415*(p-1)) + 1;
	elseif mod(round(strokesize/2*415 + spacing*415*(p-1)),2) == 0
		bincenter(p,1) = round(strokesize/2*415 + spacing*415*(p-1));
	end
end
% Plot parameters
3
figure('Position',[6 65 1271 270])
axes1 = axes(...
  'DrawMode','fast',...
  'FontWeight','bold',...
  'YGrid','on');%,...
  %'YTick',[-4 -2 0 2 4 6 8 10]);
axis(axes1,[0 420 -100 100])
xlabel('Radial Position [mm]')
ylabel('Surface Error or Removal [um]')
title(['MODS Red ' filename2 ' Scanning Run'])
box('on')
hold('all')
% First Try Loop
removalbins = zeros(size(F1x,1),l);
4
for i = k:l
	if i < 10
		filenum = ['0' num2str(i)];
	else
		filenum = num2str(i);
	end
	[x_rev,y_rev] = textread([filename4 filenum],'%f %f','delimiter',' ');
	index = max(find(y_rev == min(y_rev)));
	center_rev = x_rev(index);
	x_rev = x_rev*415;
	sep = (0:2:F1x(size(F1x,1)))';
	y_rev_new = spline(x_rev,y_rev,sep);
	F1y = F1y+y_rev_new*duration(i,2);
	stroke_center(i,1) = center_rev*415;
	removalbins(:,i) = y_rev_new;
end
for i = k:l
	avediff_pre(i,1) = abs(F1y2(bincenter(i)/2 + 1,1)-F1y(bincenter(i)/2 + 1,1))/F1y2(bincenter(i)/2 + 1,1);
end
avediff = avediff_pre([k:l],1);
% Processing Loop
5
count = 0;
while ~(max(avediff) > hi)% &  %& ~(std(avediff) > .5)
while (min(avediff) < lo)
	F1y = F1y2;
	count = 1+count
	for i = k:l
		if avediff_pre(i,1) > hi
			duration(i,2) = duration(i,2) - .5;
			F1y = F1y+removalbins(:,i)*duration(i,2);
		elseif avediff_pre(i,1) < lo
			duration(i,2) = duration(i,2) + .5;
			F1y = F1y+removalbins(:,i)*duration(i,2);
		end
	end
%%%%%%%%%%%%%%%%  Enter while loop code here
	for i = k:l
		avediff_pre(i,1) = abs(F1y2(bincenter(i)/2 + 1,1)-F1y(bincenter(i)/2 + 1,1))/F1y2(bincenter(i)/2 + 1,1);
	end
	avediff = avediff_pre([k:l],1);
%%%%%%%%%%%%%%%%
end
end
% Final plot
for i = k:l
	notch = min(removalbins(:,i))*duration(i,2):.01:0;
	try plot(F1x,removalbins(:,i)*duration(i,2),'m',stroke_center(i,1),notch,'k.',bins(i,3),notch,'b.');
	catch
	end
end
plot(F1x,F1y2,F1x,F1y,F1x,(F1y-F1y2))
hold off
% Command line and Excel data reporting
for p = 1:size(duration,1)
	bins(p,2) = duration(p,2);
end
% Write to Excel
%xlswrite([filename '_ScanningRun.xls'],bins,'Scanning Parameters')
% Display stroke parameters on screen
clc
bins
Run_Length = sum(bins(:,2))

newprofile(:,1) = F1x;
newprofile(:,2) = F1y;
%dlmwrite([filename1 '061027syn' filename3 fileext],newprofile,'-append','delimiter',' ');