clc;clear;
filename1 = '051205_120';
filename2 = '051205_140';
filename3 = '051205_160';
fileext = '.txt';
[F1x, F1y, F1z] = textread([filename1 fileext],'%f %f %f','delimiter',',');
totalsize1 = size(F1x,1)
[F2x, F2y, F2z] = textread([filename2 fileext],'%f %f %f','delimiter',',');
totalsize2 = size(F2x,1)
[F3x, F3y, F3z] = textread([filename3 fileext],'%f %f %f','delimiter',',');
totalsize3 = size(F3x,1)

for i = 1:totalsize3
	newFz(i,1) = (F1z(i) + F3z(i))/2;
	newF2x(i,1) = F2x(i);
	newF2y(i,1) = F2y(i);
	if newF2y(i,1) < 0
	r(i,1) = -sqrt(newF2x(i,1)^2 + newF2y(i,1)^2);
	elseif newF2y(i,1) > 0
	r(i,1) = sqrt(newF2x(i,1)^2 + newF2y(i,1)^2);
	end
end

data = [newF2x,newF2y,newFz];
%csvwrite([filename2 'B' fileext],data);



		% plot
		figure(1)
		close(figure(2))
		figure('Position',[6 65 1271 270]);
		axes('DrawMode','fast','YGrid','on','FontWeight','bold')	
		axis([-500 500 -10 20])
		xlabel('Radial Position [mm]')
		ylabel('Surface Error [um]')
		box('on')
		hold('all')
		plot(r*1000,1000000*newFz);
