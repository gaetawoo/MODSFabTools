clc;clear;
filename1 = 'MODSred_';
filename2 = '070713';
filename3 = '_AllData';
filename = [filename1 filename2 filename3];
fileext = '.txt';
write_rad_file = 0;
[F1x, F1y, F1z] = textread([filename fileext],'%f %f %f','delimiter',',');
totalsize = size(F1x,1);
%Z = F1z(1:totalsize);

% translates X and Y into radial positions
r = zeros(totalsize,2);
for l = 1:totalsize,
	r(l,1) = 1000*(F1x(l).^2 + F1y(l).^2).^0.5;
	r(l,2) = F1z(l)*1000000;
end

sampling = 2; % every 5 mm

ARP = zeros((ceil(max(r(:,1)))/sampling)-1,2);

for n = 1:((ceil(max(r(:,1)))/sampling)-1)
	index = find(r(:,1) >= (n*sampling) & r(:,1) < ((n + 1)*sampling));
	newN = length(index);
	subR = zeros(newN,2);
	for i = 1:newN
		subR(i,1) = r(index(i),1);
		subR(i,2) = r(index(i),2);
	end
	ARP(n + 1,1) = n*sampling;
	ARP(n + 1,2) = mean(subR(:,2));
	
	n*sampling;
	
	clear index newN subR
	end

ARP(:,2) = ARP(:,2) - min(ARP(:,2));
	
figure('Position',[6 65 1271 270])
axes('DrawMode','fast','YGrid','on','FontWeight','bold')	
axis([0 420 0 8])
xlabel('Radial Position [in]')
ylabel('Surface Error [um]')
title(['MODS Red ' filename2 ' Average Radial Profile'])
box('on')
hold('all')
plot(ARP(:,1),ARP(:,2),'r')

%keyboard

%%% convert to RAD file
if write_rad_file == 1
	dlmwrite(['MODSred_' filename2 '_ARP.txt'],ARP,'-append','delimiter',' ','precision','%6.5f');

	for t = 1:size(ARP,1)
		radARP(t,1) = ARP(t,1)/420;
		radARP(t,2) = ARP(t,2);
	end
	dlmwrite(['C:\Documents and Settings\JJ\Desktop\PCSlap\modsred\' filename2 'RP.rad'],radARP,'-append','delimiter',' ','precision','%6.5f');
end
%%%


%xlswrite([filename '_AveRadProfile.xls'],ARP)
w = 0;
on_off = 0;
if on_off == 1
	% convert into output data
	for ang = 0:10:350
		theta=pi()*ang/180;
		u = 1;
		beg = 1 + size(ARP,1)*w;
		fin = size(ARP,1)*(w+1);
		for b = 1:size(ARP)
			indici = beg:fin;
			data(indici(u),1)=(ARP(b,1)*sin(theta))/1000;
			data(indici(u),2)=(ARP(b,1)*cos(theta))/1000;
			data(indici(u),3)=(ARP(b,2))/1000000;
			u = u + 1;
		end
		w = w + 1;
		end

	bigdatafile = ['MODSblue_',datestr(now,'yymmdd'),'_ARPextrap','.txt'];
	dlmwrite(bigdatafile,data,'-append','delimiter',',');
end
RMS_full = sqrt(mean(ARP(:,2).^2)-(mean(ARP(:,2)))^2)
P_V_full = max(ARP(:,2))-min(ARP(:,2))

% clear aperture

for p = 1:162
	ARPca(p,1) = ARP(38+p,1);
	ARPca(p,2) = ARP(38+p,2);
end

RMS_ca = sqrt(mean(ARPca(:,2).^2)-(mean(ARPca(:,2)))^2)
P_V_ca = max(ARPca(:,2))-min(ARPca(:,2))