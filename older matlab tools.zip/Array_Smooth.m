function [smoothMap] = ionFigure(data,D,rMin,rMax,fwhm,palette,beforeScale,afterScale,X,Y)
%
% ionFigure(file,D,rMin,rMax,fwhm,palette,beforeScale,afterScalemaskVal,boundaryVal,delta)
%
% Performs synthetic ion figuring of NST mirror
%
% INPUT
% file      name of .int file, with full path and extension
% D         diameter of array in .int file
% rMin      of subaperture to be processed and displayed
% rMax      of subaperture to be processed and displayed
% fwhm      of Gaussian ion beam
% palette   Matlab colormap (string)
% beforeScale	[min,max] for color map for raw and smoothed data
% afterScale	[min,max] for color map for difference (residual data)
% maskVal   value to display for region outside subaperture
% boundaryVal   value to display for boundary of subaperture

map = data;
mask = (map ~= 0);
rows = size(map,1);
cols = rows;

% maskVal = -1e6;
% boundaryVal = -1e6;

%
% Use dimensions of unit circle to assign x and y coordinates to pixels.
%
fwhmPix = fwhm/(D/rows);
% Xvec = -D/2+dX/2 : dX : D/2-dX/2; 
% if length(Xvec) ~= cols
%     error('Error assigning coordinates to pixels.')
% end
%[X,Y] = meshgrid(Xvec,Xvec);
%R = sqrt(X.*X+Y.*Y);
%onMirror = (R>=rMin & R<=rMax);
%ptsOnMirror = sum(sum(onMirror));
%map = onMirror .* map;
%mask = onMirror .* mask;
%
% Define boundary of clear aperture.
%
% innerICA = rMin-delta;
% outerICA = rMin+delta;
% innerOCA = rMax-delta;
% outerOCA = rMax+delta;
% boundary = (R>innerICA & R<outerICA) | (R>innerOCA & R<outerOCA);
%
% Shrink array to unmasked area.
% 
% imin = rows;
% imax = 1;
% jmin = cols;
% jmax = 1;
% for i=1:rows
%     for j=1:cols
%         if mask(i,j)
%             if i<imin
%                 imin = i;
%             elseif i>imax
%                     imax = i;
%             end
%             if j<jmin
%                 jmin = j;
%             elseif j>jmax
%                 jmax = j;
%             end
%         end
%     end
% end
% map = map(imin:imax,jmin:jmax);
% [rows,cols] = size(map)
% mask = mask(imin:imax,jmin:jmax);
ptsInMask = sum(sum(mask));
map = (map - min(min(map))).*mask;
rms = sqrt(sum(sum(map.*map))/ptsInMask);
maxVal = max(max(map));
minVal = min(min(map));
%
% Convolve map with Gaussian.
%
smoothMap = gaussConv(map,mask,fwhmPix);
smoothMap = (smoothMap - min(min(smoothMap))).*mask;
rmsSmooth = sqrt(sum(sum(smoothMap.*smoothMap))/ptsInMask);
maxSmooth = max(max(smoothMap));
minSmooth = min(min(smoothMap));
%
% Subtract smoothed map from original map.
%
residMap = map-smoothMap;
residMap = (residMap - min(min(residMap))).*mask;
rmsResid = sqrt(sum(sum(residMap.*residMap))/ptsInMask);
maxResid = max(max(residMap));
minResid = min(min(residMap));
%
% Assign values to masked areas and boundary.
%
% for i=1:rows
%     for j=1:cols
%         if ~mask(i,j)
%             map(i,j) = maskVal;
%             smoothMap(i,j) = maskVal;
%             residMap(i,j) = maskVal;
%         end
%         if boundary(i,j)
%             map(i,j) = boundaryVal;
%             smoothMap(i,j) = boundaryVal;
%             residMap(i,j) = boundaryVal;
%         end
%     end
% end
%
% Display maps.
%

close all
figure
pcolor(X,Y,map)
shading interp
axis equal
axis tight
xlabel('X [mm]')
ylabel('Y [mm]')
colormap(palette)
caxis(beforeScale)
colorbar(...
  'Box','on',...
  'YMinorTick','on',...
  'YTick',min(beforeScale):1:max(beforeScale),...
  'YLim',[beforeScale]);
title(['original: ',num2str(rms,'%.1f'),' um rms, range = (',...
    num2str(minVal,'%.0f'),',',num2str(maxVal,'%.0f'),')'])

figure
pcolor(X,Y,smoothMap)
shading interp
axis equal
axis tight
xlabel('X [mm]')
ylabel('Y [mm]')
colormap(palette)
caxis(beforeScale)
colorbar(...
  'Box','on',...
  'YMinorTick','on',...
  'YTick',min(beforeScale):1:max(beforeScale),...
  'YLim',[beforeScale]);
title(['smoothed: ',num2str(rmsSmooth,'%.1f'),' um rms, range = (',...
    num2str(minSmooth,'%.0f'),',',num2str(maxSmooth,'%.0f'),')'])

figure
pcolor(X,Y,residMap)
shading interp
axis equal
axis tight
xlabel('X [mm]')
ylabel('Y [mm]')
colormap(palette)
caxis(afterScale)
colorbar(...
  'Box','on',...
  'YMinorTick','on',...
  'YTick',min(afterScale):1:max(afterScale),...
  'YLim',[beforeScale]);
title(['residual: ',num2str(rmsResid,'%.1f'),' um rms, range = (',...
    num2str(minResid,'%.0f'),',',num2str(maxResid,'%.0f'),')'])