%clc;
clear;
filename1 = 'MODS Red ';
filename2 = '061023';
filename = [filename1 filename2];
fileext = '.rad';
write_rad_file = 0;
[F1x, F1y] = textread([filename fileext],'%f %f','delimiter','/t');
ARP(:,1) = F1x*1000;
ARP(:,2) = F1y*1000000-0;

figure('Position',[6 65 1271 270])
axes('DrawMode','fast','YGrid','on','FontWeight','bold')	
axis([0 420 0 200])
xlabel('Radial Position [mm]')
ylabel('Surface Error [um]')
title(['MODS Red ' filename2 ' Average Radial Profile'])
box('on')
hold('all')
plot(ARP(1:99,1),ARP(1:99,2),'r')

['MODS Red ' filename2 ' Average Radial Profile']
PV = max(ARP(1:99,2))-min(ARP(1:99,2))
RMS = std(ARP(1:99,2))