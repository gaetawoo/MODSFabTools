function cold_fusion(mat,map)
%
% generates a 3D plot based on the datapoints in the input matrix, mat, and
%   plot it with colormap, map
%
% note: mat must have all x values in the first column, y values in the
%   seconds column, and z values in the third column
%
% to test this function, type (at the command prompt): 
%
%       mat = rand(500,3);
%       you_owe_me_piccuros(mat,jet)

N = size(mat,1);

% generates colormap
col = [[interp1(1:size(map,1),map(:,1),linspace(1,size(map,1),N),'pchip')']...
    [interp1(1:size(map,1),map(:,2),linspace(1,size(map,1),N),'pchip')']...
    [interp1(1:size(map,1),map(:,3),linspace(1,size(map,1),N),'pchip')']];

% sorts values according to z value
[V I] = sort(mat(:,3));
mat = mat(I,:);

% plots points with color corresponding to z value
figure    

for ii = 1:N
	plot3(mat(ii,1),mat(ii,2),mat(ii,3),'.','color',col(ii,:));
    hold all
end
xlabel('x')
ylabel('y')
zlabel('z')
set(gca,'CameraPosition',[0 0 90],'DataAspectRatio',[1 1 1])
hold off