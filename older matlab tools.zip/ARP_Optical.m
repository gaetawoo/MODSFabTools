clc;clear;
filename1 = 'MODSblueOPT_';
filename2 = '060210';
filename3 = '_ARP';
filename = [filename1 filename2 filename3];
fileext = '.txt';
write_rad_file = 0;
[ARP(:,1), ARP(:,2), dead1, dead2] = textread([filename fileext],'%f %f %f %f','delimiter','\t');
totalsize = size(ARP(:,1),1);

ARP(:,2) = ARP(:,2) - min(ARP(:,2));

figure('Position',[6 65 1271 270])
axes('DrawMode','fast','YGrid','on','FontWeight','bold')	
axis([0 420 -2 13])
xlabel('Radial Position [mm]')
ylabel('Surface Error [um]')
title(['MODS Blue ' filename2 ' Optical Average Radial Profile'])
box('on')
hold('all')
plot(ARP(:,1),ARP(:,2),'k')